		<script src="<?php echo base_url();?>static/jquery.1102.min.js"></script>
		<script src="<?php echo base_url();?>static/bootstrap/js/bootstrap.min.js"></script>
	</body>
</html>