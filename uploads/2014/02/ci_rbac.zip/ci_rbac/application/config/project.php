<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Project config
|--------------------------------------------------------------------------
*/

$config['project_name']	        = "Rbac Project";			      		//项目名称
$config['project_copyright']	= "Copyright @ ToryZen";			    //版权信息
/* End of file rbac.php */
/* Location: ./application/config/project.php */
