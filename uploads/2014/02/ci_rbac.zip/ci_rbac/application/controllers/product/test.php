<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Test extends CI_Controller {
	
	function __construct(){
		parent::__construct();
	}

	public function index()
	{
		echo "111";
	}
	public function detail(){
		echo "---";
	}

}
