﻿namespace AutoCall
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.start_btn = new System.Windows.Forms.Button();
            this.stop_btn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.eachtimes = new System.Windows.Forms.TextBox();
            this.uuid = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.phones = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // start_btn
            // 
            this.start_btn.Location = new System.Drawing.Point(12, 225);
            this.start_btn.Name = "start_btn";
            this.start_btn.Size = new System.Drawing.Size(51, 39);
            this.start_btn.TabIndex = 4;
            this.start_btn.Text = "去死吧";
            this.start_btn.UseVisualStyleBackColor = true;
            this.start_btn.Click += new System.EventHandler(this.start_btn_Click);
            // 
            // stop_btn
            // 
            this.stop_btn.Location = new System.Drawing.Point(72, 225);
            this.stop_btn.Name = "stop_btn";
            this.stop_btn.Size = new System.Drawing.Size(51, 39);
            this.stop_btn.TabIndex = 5;
            this.stop_btn.Text = "饶一命";
            this.stop_btn.UseVisualStyleBackColor = true;
            this.stop_btn.Click += new System.EventHandler(this.stop_btn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 194);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "停顿间隔:";
            // 
            // eachtimes
            // 
            this.eachtimes.Location = new System.Drawing.Point(68, 191);
            this.eachtimes.Name = "eachtimes";
            this.eachtimes.Size = new System.Drawing.Size(55, 21);
            this.eachtimes.TabIndex = 7;
            this.eachtimes.Text = "60";
            // 
            // uuid
            // 
            this.uuid.Location = new System.Drawing.Point(68, 164);
            this.uuid.Name = "uuid";
            this.uuid.Size = new System.Drawing.Size(55, 21);
            this.uuid.TabIndex = 9;
            this.uuid.Text = "ID号";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 10;
            this.label5.Text = "QQVoice:";
            // 
            // phones
            // 
            this.phones.Location = new System.Drawing.Point(12, 12);
            this.phones.Name = "phones";
            this.phones.Size = new System.Drawing.Size(111, 118);
            this.phones.TabIndex = 11;
            this.phones.Text = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 12);
            this.label4.TabIndex = 12;
            this.label4.Text = "每行一号，随机抽取";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(137, 273);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.phones);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.uuid);
            this.Controls.Add(this.eachtimes);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.stop_btn);
            this.Controls.Add(this.start_btn);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(153, 311);
            this.MinimumSize = new System.Drawing.Size(153, 311);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button start_btn;
        private System.Windows.Forms.Button stop_btn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox eachtimes;
        private System.Windows.Forms.TextBox uuid;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox phones;
        private System.Windows.Forms.Label label4;
    }
}

