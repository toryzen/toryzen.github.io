﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace AutoCall
{
    public partial class Form1 : Form
    {
        public IntPtr jian = IntPtr.Zero, b_1 = IntPtr.Zero, b_2 = IntPtr.Zero, b_3 = IntPtr.Zero, b_4 = IntPtr.Zero, b_5 = IntPtr.Zero, b_6 = IntPtr.Zero, b_7 = IntPtr.Zero, b_8 = IntPtr.Zero, b_9 = IntPtr.Zero, b_0 = IntPtr.Zero, call = IntPtr.Zero, hangup = IntPtr.Zero;
        public Thread SoftBeginThread;
        public string phoneNum;
        public Form1()
        {
            InitializeComponent();
            this.MaximizeBox = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            changeUI(0);
        }

        private void beginCall() {
            this.setHandle();
            while (true)
            {
                Action<string> param1 = s => GetNum(s);
                this.Invoke(param1, "");

                for (int j = 0; j <= 11; j++)
                {
                    this.click("jian");
                }

                for (int i = 0; i <= phoneNum.Length; i++)
                {
                    try
                    {
                        string s = phoneNum.Substring(i, 1);
                        this.click(s);
                        Thread.Sleep(500);
                    }
                    catch { }
                }
                Thread.Sleep(5 * 1000);
                this.click("start");
                Thread.Sleep(Int32.Parse(this.eachtimes.Text) * 1000);
                this.click("end");
                Thread.Sleep(5 * 1000);
            }
        }

        private void click(string i) {
            const int WM_LBUTTONDOWN = 0x0201;
            const int WM_LBUTTONUP = 0x0202;
            if (i == "1")
            {
                Program.PostMessage(b_1, WM_LBUTTONDOWN, 0, 0);
                Program.PostMessage(b_1, WM_LBUTTONUP, 0, 0);
            }
            if (i == "2") {
                Program.PostMessage(b_2, WM_LBUTTONDOWN, 0, 0);
                Program.PostMessage(b_2, WM_LBUTTONUP, 0, 0);
            }
            if (i == "3")
            {
                Program.PostMessage(b_3, WM_LBUTTONDOWN, 0, 0);
                Program.PostMessage(b_3, WM_LBUTTONUP, 0, 0);
            }
            if (i == "4")
            {
                Program.PostMessage(b_4, WM_LBUTTONDOWN, 0, 0);
                Program.PostMessage(b_4, WM_LBUTTONUP, 0, 0);
            }
            if (i == "5")
            {
                Program.PostMessage(b_5, WM_LBUTTONDOWN, 0, 0);
                Program.PostMessage(b_5, WM_LBUTTONUP, 0, 0);
            }
            if (i == "6")
            {
                Program.PostMessage(b_6, WM_LBUTTONDOWN, 0, 0);
                Program.PostMessage(b_6, WM_LBUTTONUP, 0, 0);
            }
            if (i == "7")
            {
                Program.PostMessage(b_7, WM_LBUTTONDOWN, 0, 0);
                Program.PostMessage(b_7, WM_LBUTTONUP, 0, 0);
            }
            if (i == "8")
            {
                Program.PostMessage(b_8, WM_LBUTTONDOWN, 0, 0);
                Program.PostMessage(b_8, WM_LBUTTONUP, 0, 0);
            }
            if (i == "9")
            {
                Program.PostMessage(b_9, WM_LBUTTONDOWN, 0, 0);
                Program.PostMessage(b_9, WM_LBUTTONUP, 0, 0);
            }
            if (i == "0")
            {
                Program.PostMessage(b_0, WM_LBUTTONDOWN, 0, 0);
                Program.PostMessage(b_0, WM_LBUTTONUP, 0, 0);
            }
            if (i == "jian")
            {
                Program.PostMessage(jian, WM_LBUTTONDOWN, 0, 0);
                Program.PostMessage(jian, WM_LBUTTONUP, 0, 0);
            }
            if (i == "start")
            {
                Program.PostMessage(call, WM_LBUTTONDOWN, 0, 0);
                Program.PostMessage(call, WM_LBUTTONUP, 0, 0);
            }
            if (i == "end")
            {
                Program.PostMessage(hangup, WM_LBUTTONDOWN, 0, 0);
                Program.PostMessage(hangup, WM_LBUTTONUP, 0, 0);
            }
        
        }

        private void setHandle() {  
            IntPtr hwndCalc = Program.FindWindow(null, "QQVoice");
            IntPtr panel = Program.FindWindowEx(hwndCalc, IntPtr.Zero, null, this.uuid.Text);
            this.call = Program.FindWindowEx(panel, IntPtr.Zero, "Button", "call");
            this.hangup = Program.FindWindowEx(panel, IntPtr.Zero, "Button", "hang up");
            IntPtr p = IntPtr.Zero;
            do
            {
                p = Program.FindWindowEx(panel, p, "#32770", null);
                if (!p.Equals(IntPtr.Zero))
                {
                    if (!Program.FindWindowEx(p, IntPtr.Zero, "Button", "1").Equals(IntPtr.Zero))
                    {
                        this.b_1 = Program.FindWindowEx(p, IntPtr.Zero, "Button", "1");
                    }
                    if (!Program.FindWindowEx(p, IntPtr.Zero, "Button", "2").Equals(IntPtr.Zero))
                    {
                        this.b_2 = Program.FindWindowEx(p, IntPtr.Zero, "Button", "2");
                    }
                    if (!Program.FindWindowEx(p, IntPtr.Zero, "Button", "3").Equals(IntPtr.Zero))
                    {
                        this.b_3 = Program.FindWindowEx(p, IntPtr.Zero, "Button", "3");
                    }
                    if (!Program.FindWindowEx(p, IntPtr.Zero, "Button", "4").Equals(IntPtr.Zero))
                    {
                        this.b_4 = Program.FindWindowEx(p, IntPtr.Zero, "Button", "4");
                    }
                    if (!Program.FindWindowEx(p, IntPtr.Zero, "Button", "5").Equals(IntPtr.Zero))
                    {
                        this.b_5 = Program.FindWindowEx(p, IntPtr.Zero, "Button", "5");
                    }
                    if (!Program.FindWindowEx(p, IntPtr.Zero, "Button", "6").Equals(IntPtr.Zero))
                    {
                        this.b_6 = Program.FindWindowEx(p, IntPtr.Zero, "Button", "6");
                    }
                    if (!Program.FindWindowEx(p, IntPtr.Zero, "Button", "7").Equals(IntPtr.Zero))
                    {
                        this.b_7 = Program.FindWindowEx(p, IntPtr.Zero, "Button", "7");
                    }
                    if (!Program.FindWindowEx(p, IntPtr.Zero, "Button", "8").Equals(IntPtr.Zero))
                    {
                        this.b_8 = Program.FindWindowEx(p, IntPtr.Zero, "Button", "8");
                    }
                    if (!Program.FindWindowEx(p, IntPtr.Zero, "Button", "9").Equals(IntPtr.Zero))
                    {
                        this.b_9 = Program.FindWindowEx(p, IntPtr.Zero, "Button", "9");
                    }
                    if (!Program.FindWindowEx(p, IntPtr.Zero, "Button", "0").Equals(IntPtr.Zero))
                    {
                        this.b_0 = Program.FindWindowEx(p, IntPtr.Zero, "Button", "0");
                        jian = Program.FindWindowEx(p, IntPtr.Zero, "Button", "-");
                    }
                    //MessageBox.Show(this.jian);

                }
            } while (!p.Equals(IntPtr.Zero));
        }

        public void GetNum(string s)
        {
            String cont;

            while (true)
            {
                try
                {
                    Random ros = new Random();
                    int iR = ros.Next(0, this.phones.Lines.Length);
                    cont = this.phones.Lines[iR].ToString();
                }
                catch
                {
                    cont = "";
                }
                if (cont != "") break;
            }
            this.phoneNum = cont;
        }

        private void changeUI(int s){
            if(s==1){
                this.start_btn.Enabled =false;
                this.stop_btn.Enabled = true;
                this.eachtimes.Enabled = false;
                this.phones.Enabled = false;
                this.uuid.Enabled = false;
            }
            else{
                this.start_btn.Enabled =true;
                this.stop_btn.Enabled = false;
                this.eachtimes.Enabled = true;
                this.phones.Enabled = true;
                this.uuid.Enabled = true;
            }
        
        }

        private void start_btn_Click(object sender, EventArgs e)
        {
            SoftBeginThread = new Thread(this.beginCall);
            SoftBeginThread.SetApartmentState(ApartmentState.STA);
            SoftBeginThread.Start();
            changeUI(1);
        }

        private void stop_btn_Click(object sender, EventArgs e)
        {
            this.click("end");
            SoftBeginThread.Abort();
            changeUI(0);
        }
    }
}
