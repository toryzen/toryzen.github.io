<?php  if ( ! defined('SYSTEM')) exit('Go away!');

class V{

    public $contents;
    
    public function output(){
    
        echo $this->contents;
        
    }
    
}