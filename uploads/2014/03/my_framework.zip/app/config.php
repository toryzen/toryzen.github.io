<?php
$config['db']['hostname'] = 'localhost';
$config['db']['username'] = 'root';
$config['db']['password'] = '';
$config['db']['database'] = 'ci_rbac';
$config['db']['char_set'] = 'utf8';
